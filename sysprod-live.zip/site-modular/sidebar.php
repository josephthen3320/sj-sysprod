<style>
    /* Styles for action buttons */
    .action-button {
        font-weight: 400 !important;
        padding-left: 32px !important;
    }
    i {
        display: inline-block;
        width: 20px;
        justify-content: center;
    }

    .sj-content {
        margin-top: 45px;
    }


    @media only screen and (max-width: 600px) {
        .sj-content {
            margin-left: 0 !important;
        }
    }
</style>

<!-- Side navigation bar -->
<div class="w3-quarter w3-text-white w3-hide-small" style="min-height: 100vh; position: fixed; background-color: #0B293C">
    <!-- Header -->
    <div class="w3-container w3-padding-16" style="display:flex;justify-content: center;  align-items: center; width: 100%; height: 100px; background-color: #156992">
        <div class="w3-container w3-quarter w3-center">
            <img class="w3-circle w3-white" src="/assets/logo/SJ_Logo.png" width="80px">
        </div>
        <div class="w3-container w3-threequarter w3-left-align" style="padding-left: 30px">
            <span class="w3-xlarge" style="font-weight: bolder;">CV. SUBUR JAYA</span><br>
            <span class="w3-medium w3-monospace">Production System</span>
        </div>
    </div>

    <!-- General section -->
    <div class="w3-container w3-padding-16 w3-border-bottom w3-border-orange" style="padding-left: 32px;">
        <span class="w3-large" style="font-weight: 400;">General</span>
    </div>

    <div class="w3-padding-16 w3-bar-block" style="">
        <a class="w3-medium w3-button w3-bar-item action-button" href="/dashboard/"><i class="fa-solid fa-gauge-high w3-text-orange"></i> &nbsp;&nbsp; Dashboard</a>
        <a class="w3-medium w3-button w3-bar-item action-button" href="/support/"><i class="fa-solid fa-headset w3-text-red"></i> &nbsp;&nbsp; Support</a>

        <?php
        $userManagementButton = '<a class="w3-medium w3-button w3-bar-item action-button" href="/admin/user-management"><i class="fa-solid fa-user w3-text-red"></i> &nbsp;&nbsp; User Management</a>';

        echo ($_SESSION['user_role'] <= 1) ? $userManagementButton : "";

        ?>
    </div>

    <!-- Production section -->
    <?php

        if ($_SESSION['user_role'] != 4) {
            echo "
            <div class=\"w3-container w3-padding-16 w3-border-bottom w3-border-top w3-border-orange\" style=\"padding-left: 32px;\">
                <span class=\"w3-large\" style=\"font-weight: 400;\">Pre-Production</span>
            </div>
        
            <div class=\"w3-padding-16 w3-bar-block\" style=\"\">
                <a class=\"w3-medium w3-button w3-bar-item action-button\" href=\"/production/\"><i class=\"fa-solid fa-gauge-high w3-text-orange\"></i> &nbsp;&nbsp; Production Dashboard</a>
        
                <a class=\"w3-medium w3-button w3-bar-item action-button\" href=\"/production/classification.php\"><i class=\"fa-solid fa-database w3-text-blue\"></i> &nbsp;&nbsp; Classification</a>
                <a class=\"w3-medium w3-button w3-bar-item action-button\" href=\"/production/article.php\"><i class=\"fa-solid fa-clothes-hanger w3-text-green\"></i> &nbsp;&nbsp; Article</a>
                <a class=\"w3-medium w3-button w3-bar-item action-button\" href=\"/production/worksheet.php\"><i class=\"fa-solid fa-file-lines w3-text-yellow\"></i> &nbsp;&nbsp; Worksheet</a>
            </div>
            ";
        }

    ?>




    <!-- Transaction section -->
    <div class="w3-container w3-padding-16 w3-border-bottom w3-border-top w3-border-orange" style="padding-left: 32px;">
        <span class="w3-large" style="font-weight: 400;">Transaction</span>
    </div>

    <div class="w3-padding-16 w3-bar-block" style="">
        <a class="w3-medium w3-button w3-bar-item action-button" href="/transaction/"><i class="fa-solid fa-gauge-high w3-text-orange"></i> &nbsp;&nbsp; Transaction Dashboard</a>
    </div>

    </div>
