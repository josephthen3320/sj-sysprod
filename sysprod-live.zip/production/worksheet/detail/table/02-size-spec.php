<?php
/**
 * Created by PhpStorm.
 * User: Lenovo
 * Date: 14/06/2023
 * Time: 13:34
 */

echo "TABLE 2 STUB";