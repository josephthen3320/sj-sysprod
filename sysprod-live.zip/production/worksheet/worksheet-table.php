<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/w3.css">
    <link rel="stylesheet" href="/assets/fontawesome/css/all.css" type="text/css">
</head>
<script src="/assets/js/utils.js"></script>
<body>
<div class="w3-container classification-content" id="worksheet-modal" style="">
    <table class="w3-table w3-table-all">
        <thead>
        <tr>
            <th>No</th>
            <th>Worksheet No.</th>
            <th>Article ID.</th>
            <th>Worksheet Date.</th>
            <th>PO Date</th>
            <th>Actions</th>
            <th>Send to</th>
            <th>Current Position</th>
        </tr>
        </thead>
        <tbody>
        <?php
        include $_SERVER['DOCUMENT_ROOT'] . '/php-modules/utilities/util_worksheet.php';
        include $_SERVER['DOCUMENT_ROOT'] . '/php-modules/utilities/util_worksheet_position.php';

        $worksheets = getAllWorksheet();

        foreach ($worksheets as $index => $worksheet) {
            $worksheetId = $worksheet['worksheet_id'];
            $details = fetchWorksheetDetails($worksheetId);

            echo "<tr>";
            echo "  <td>" . ($index + 1) . "</td>";
            echo "  <td>{$worksheet['worksheet_id']}</td>";

            echo "  <td>{$details['article_id']}</td>";
            echo "  <td>{$worksheet['worksheet_date']}</td>";
            echo "  <td>{$worksheet['po_date']}</td>";

            $id = $details['id'];
            echo "  <td>
                        <button class='w3-button w3-blue-gray' onclick='openPopupURL35(\"detail?id=" . $id . "\", \"wsdetail\")'><i class='fa-solid fa-magnifying-glass'></i></button>
                        <button class='w3-button w3-green' onclick='openPopupURL(\"export.php?id=" . $id . "\", \"wsgenerate\")'><i class='fa-solid fa-file-export'></i></button>
                        <button class='w3-button w3-red' onclick='openPopupURL(\"delete?id=" . $id . "\", \"wsdelete\")'><i class='fa-solid fa-trash'></i></button>
                    </td>";


            echo "<td>";
            if (getWorksheetPosition($worksheetId) <= 0) {
                echo "<button class='w3-button w3-red' onclick='openURL(\"send-to-polamarker.php?w=" . $worksheetId . "\")'>Pola Marker&nbsp;&nbsp;<i class=\"fa-solid fa-arrow-right-from-arc\"></i></button>";
            } else {
                echo "<button class='w3-button w3-hover-red w3-red w3-disabled'>Pola Marker&nbsp;&nbsp;<i class=\"fa-solid fa-arrow-right-from-arc\"></i></button>";
            }
            echo "</td>";

            $pos = parseWorksheetPosition(getWorksheetPosition($worksheetId));
            $url = "/transaction/" . strtolower(str_replace(" ", "-", $pos));
            $url = str_replace("unknown", "", $url);    // remove link if unknown
            // Link to process view
            echo "<td><a href='$url' target='_blank'>{$pos}</a></td>";
            echo "</tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>