<?php
session_start();
include_once $_SERVER['DOCUMENT_ROOT'] . "/php-modules/verify-session.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/w3.css">
    <link rel="stylesheet" href="/assets/fontawesome/css/all.css" type="text/css">

  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      /*display: flex;
      align-items: center;
      justify-content: center;*/
      height: 100vh;
    }

    form {
      background-color: #f1f1f1;
      padding: 20px;
      border-radius: 4px;
    }
/*
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
*/
    input[type="submit"] {
      background-color: #D50B08;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #c30907;
    }

    .error-message {
      color: red;
    }
  </style>
</head>
<body class="w3-light-grey">
  <?php

    include_once $_SERVER['DOCUMENT_ROOT'] . "/php-modules/db.php";
    $conn = getConnUser();

	if ($_SERVER["REQUEST_METHOD"] == "POST") {

        include $_SERVER['DOCUMENT_ROOT'] . "/php-modules/agents/logging.php";
        $log_details = "";

		$username = $_POST['username'];
		$password = $_POST['password'];
		$first_name = $_POST['firstname'];
		$last_name = $_POST['lastname'];
		$email = $_POST['email'];
		$department = $_POST['department'];

		// Check if the username already exists in user_accounts table
		$sqlCheckUsername = "SELECT * FROM user_accounts WHERE username = '$username'";
		$result = $conn->query($sqlCheckUsername);

		if ($result->num_rows > 0) {
			// Username already exists
			echo "Username already registered";
		} else {
			// Hash the password
			$hashedPassword = hash('sha256', $password);

			// Insert into user_accounts table
			$sqlUserAccounts = "INSERT INTO user_accounts (username, password, email) VALUES ('$username', '$hashedPassword', '$email')";

			$conn->query($sqlUserAccounts);

			// Get the user id to input into users table
            $idQuery = "SELECT id FROM user_accounts WHERE username = '$username'";
            $idQueryResults = $conn->query($idQuery);

            if ($idQueryResults->num_rows > 0) {
                // output data of each row
                while($row = $idQueryResults->fetch_assoc()) {
                    $user_id = $row["id"];
                    print $user_id;
                }
            } else {
                // todo: id not found behaviour and check.
                echo "0 results";
            }

            $log_details .= "USER CREATED; new_user_detail={$username}({$user_id});";

			// Insert into users table
			$sqlUsers = "INSERT INTO users (user_id, username, first_name, last_name, department) VALUES ('$user_id', '$username', '$first_name', '$last_name', '$department')";

			if ($conn->query($sqlUsers) === TRUE) {
				// User created successfully

                logGeneric($_SESSION['user_id'], 1, $log_details);

				echo "User created successfully";
			} else {
				echo "Error creating user: " . $conn->error;
			}
		}
	}

	$conn->close();
	?>

  <div class="w3-bar w3-top w3-text-white" style="background-color: #0B293C;">
      <span class="w3-bar-item w3-xlarge">Create User</span>
  </div>

  <div class="w3-container w3-light-grey" style="width: 75%; margin-top: 96px; margin-left: 12.5%">
      <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
          <div class="">
              <h5>Account Detail</h5>
              <input class="w3-input w3-border" type="text" name="username" placeholder="Username" required>
              <input class="w3-input w3-border" type="password" name="password" placeholder="Password" required>
          </div>
          <div class="">
              <h5>User Information</h5>
              <input class="w3-input w3-border" type="text" name="firstname" id="firstname" placeholder="First Name" required>
              <input class="w3-input w3-border" type="text" name="lastname" id="lastname" placeholder="Last Name" required>
              <label class="w3-small" for="lastname">Name</label>

              <input class="w3-input w3-border" type="email" name="email" id="email" placeholder="kucing@example.com" required>
              <label class="w3-small" for="email">Email</label>

              <select class="w3-select" name="department" required>
                  <option disabled hidden selected>Select department</option>
                  <option value="Produksi">Produksi</option>
                  <option value="ITS">ITS</option>
                  <option value="HRD">HRD</option>
                  <option value="Akunting">Akunting</option>
                  <option value="Lain-lain">Lain-lain</option>
              </select>

          </div>

          <div class="" style="margin-top: 40px">
              <input class="w3-padding-16" type="submit" value="Create User" style="width: 100%;">
          </div>
      </form>
  </div>





  <!--form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <h2>Create User</h2>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="name" placeholder="Name" required>
    <input type="text" name="employee_id" placeholder="Employee ID" required>
    <input type="submit" value="Create User">
  </form-->
</body>
</html>
